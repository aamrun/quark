start,end = 511,513
for i in range(0,39):
 print(f"{start},{end}",end=" ")
 start += 11
 end = start + 2
